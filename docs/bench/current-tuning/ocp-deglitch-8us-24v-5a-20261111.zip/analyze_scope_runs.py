"""Analyze saved captures only; no MCU or viewer access."""
from pathlib import Path
from bisect import bisect_right
import hashlib,json,statistics,zipfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

base=Path(__file__).resolve().parent
root=base.parents[2]
report_path=root/'docs/bench/2026-11-11-ocp-deglitch-8us-24v-5a.json'
report=json.loads(report_path.read_text(encoding='utf-8'))
baseline=base/'baseline2us'
if not baseline.exists():baseline=root/'outputs/checkpoints/current-ramp-fault-fix-24v-2026-11-11'
records=[(baseline,'run-5a','2us baseline',2),
         (base/'verified-readback','run-5a','8us bounded1',8),
         (base/'verified-readback','scope-run-5a','8us bounded2 with scope',8),
         (base/'continuous-5a','scope-continuous','8us continuous, EVM scope ground',8),
         (base/'continuous-5a','scope-stm-ground','8us continuous, STM scope ground',8),
         (base/'continuous-5a','scope-improved-ground','8us continuous, improved STM-to-DRV ground',8)]
saved=[];rows=[]
def interpolate(times,values,t):
    i=bisect_right(times,t)-1
    if i<0:return values[0]
    if i>=len(times)-1:return values[-1]
    u=(t-times[i])/(times[i+1]-times[i])
    return values[i]+u*(values[i+1]-values[i])
for folder,label,title,us in records:
    if not (folder/(label+'-after.json')).exists():continue
    c=json.loads((folder/(label+'-capture.json')).read_text());cv=c['curves']
    if not cv:continue
    a=json.loads((folder/(label+'-armed.json')).read_text())['signals']
    post=json.loads((folder/(label+'-after.json')).read_text());z=post['signals']
    rc=cv['g_tune_reference']
    pairs=[(t,interpolate(rc['times'],rc['values'],t),v) for t,v in zip(cv['g_tune_measured']['times'],cv['g_tune_measured']['values'])]
    vals=[(t,r,v) for t,r,v in pairs if r>=4.995]
    tail=[v for t,r,v in vals if t>=vals[-1][0]-10]
    row={'label':title,'OCP_deglitch_us':us,'mean_A':statistics.mean(v for t,r,v in vals),
         'MAE_A':statistics.mean(abs(v-r) for t,r,v in vals),'last10s_mean_A':statistics.mean(tail),
         'plateau_samples':len(vals),'capture_span_s':max(cv['g_tune_measured']['times'])-min(cv['g_tune_measured']['times']),
         'host_stop_elapsed_s':c.get('samples',[{}])[-1].get('elapsed_s'),
         'native_curve_points':cv['g_tune_measured'].get('total'),
         'exported_curve_points':len(cv['g_tune_measured']['times']),
         'voltage_peak_V':max(map(abs,cv['g_tune_voltage']['values'])),
         'sampled_saturation_count':sum(v>.5 for v in cv['g_tune_saturated']['values']),
         'inactive_IRQ_delta':z['g_repo_fault_irq_rejected']-a['g_repo_fault_irq_rejected'],
         'total_fault_IRQ_delta':z['g_repo_fault_irq_seen']-a['g_repo_fault_irq_seen'],
         'Hall_changes':z['g_tune_hall_changes']-a['g_tune_hall_changes'],
         'Hall_invalid_delta':z['g_tune_hall_invalid']-a['g_tune_hall_invalid'],
         'Hall_multibit_delta':z['g_tune_hall_multibit']-a['g_tune_hall_multibit'],
         'half_moves':z['g_tune_half_moves'],'state':z['g_tune_state'],'reason':z['g_tune_reason'],'result':z['g_tune_result'],
         'IRQ_max_us':z['g_repo_irq_max_cycles']/100,'armed_bus_V':a['g_repo_bus_mv']/1000,
         'active_fault_capture_delta':z['g_repo_fault_capture_count']-a['g_repo_fault_capture_count'],
         'recorder_fault':z['g_tune_recorder_fault'],'CPU_CFSR':post['registers']['0xe000ed28'],'CPU_HFSR':post['registers']['0xe000ed2c'],
         'outputs_disabled':int(post['registers']['0x40020414'],16)&1==0 and int(post['registers']['0x40020814'],16)&0x2c0==0 and int(post['registers']['0x40010044'],16)&0x8000==0,
         'capture':str((folder/(label+'-capture.json')).relative_to(root)).replace('\\','/')}
    if us==8:row['R5_frames']=[hex(a[k]) for k in ['g_repo_ocp_first','g_repo_ocp_verify_first','g_repo_ocp_control']]
    assert row['state']==0 and row['outputs_disabled'] and row['result']==0
    rows.append(row);saved.append((folder,label,title,c))
report['bounded_runs']=rows[:3];report['continuous_runs']=rows[3:]
report['statistics_method']='Unweighted exported trend samples, reference interpolated to measured-current timestamps and >=4.995A. Native sampling100Hz; long exports capped/decimated to10000points per curve on independent grids. Voltage/saturation use exported whole trend; not raw20kHz extrema or a complete saturation count. IRQ maximum cumulative since boot. Capture span/host stop time include polling latency.'
report.setdefault('final_state',{})
report['status']='DONE_WITH_CONCERNS: motion experiments completed; electrical grounding/measurement dependence remains unresolved'
report['physical_state']='MCU disarmed and outputs LOW; user confirmed EVM OFF after final improved-ground run'
report_path.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
(base/'comparison.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
fig,axes=plt.subplots(len(saved),2,figsize=(12,3*len(saved)),constrained_layout=True,squeeze=False)
for i,((folder,label,title,c),row) in enumerate(zip(saved,rows)):
    cv=c['curves'];ax=axes[i,0]
    for name,color,legend in [('g_tune_reference','#111827','Reference'),('g_tune_measured','#2563eb','Measured D')]:
        ax.plot(cv[name]['times'],cv[name]['values'],color=color,lw=1,label=legend)
    ax.set(title=title+f"; mean {row['mean_A']:.3f} A",xlabel='Capture time (s)',ylabel='Current (A)');ax.grid(alpha=.2)
    if i==0:ax.legend(loc='lower right')
    ax=axes[i,1];cmd=cv['g_tune_command_mech_rev']
    points=[(interpolate(cmd['times'],cmd['values'],t),h) for t,h in zip(cv['g_tune_hall_state']['times'],cv['g_tune_hall_state']['values'])]
    ax.plot([x for x,h in points],[h for x,h in points],'.',ms=2,color='#2563eb')
    ax.set(title=f"{row['Hall_changes']} Hall edges; {row['inactive_IRQ_delta']:,} inactive IRQs",xlabel='Commanded mechanical rotation (rev)',ylabel='Hall UVW code',yticks=range(1,7),ylim=(.5,6.5));ax.grid(alpha=.2)
fig.suptitle('24 V / 5 A scope investigation: 2us versus 8us OCP qualification\nKp1.0 / Ki2500; 3.2V ceiling; angle is commanded, not independently measured',fontsize=13)
plot=root/'docs/bench/current-tuning/ocp-deglitch-8us-24v-5a-20261111.png'
fig.savefig(plot,dpi=130);plt.close(fig)
with zipfile.ZipFile(root/'docs/bench/current-tuning/ocp-deglitch-8us-24v-5a-20261111.zip','w',zipfile.ZIP_DEFLATED) as output:
    for folder,label,title,c in saved:
        category='baseline2us' if folder.name=='current-ramp-fault-fix-24v-2026-11-11' else folder.name
        for suffix in ['-capture.json','-armed.json','-after.json','-armed-readback.txt','-after-readback.txt']:
            f=folder/(label+suffix)
            if f.exists():output.write(f,category+'/'+f.name)
    output.write(base/'comparison.json','comparison.json')
    output.write(Path(__file__),'analyze_scope_runs.py')
    setup=base/'continuous-5a/improved-ground-setup.json'
    if setup.exists():output.write(setup,'continuous-5a/improved-ground-setup.json')
print(json.dumps(rows,indent=2))
