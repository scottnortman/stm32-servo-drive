"""Reproduce the selected trends, summary and plot from this archive's captures."""
import hashlib
import json
from pathlib import Path
import shutil
import statistics
import zipfile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

archive = Path(__file__).resolve().parent
root = archive.parents[2]
bench = root / "docs/bench"
trends = bench / "current-tuning"
rows = []
fig, axes = plt.subplots(5, 2, figsize=(12, 15), constrained_layout=True)
for a in range(1, 6):
    capture = json.loads((archive / f"run-{a}a-capture.json").read_text())
    before = json.loads((archive / f"run-{a}a-armed.json").read_text())["signals"]
    after_document = json.loads((archive / f"run-{a}a-after.json").read_text())
    after = after_document["signals"]
    curves = capture["curves"]
    ref = dict(zip(curves["g_tune_reference"]["times"], curves["g_tune_reference"]["values"]))
    plateau = [(ref[t], v) for t, v in zip(curves["g_tune_measured"]["times"], curves["g_tune_measured"]["values"])
               if t in ref and ref[t] >= a * .999]
    row = {
        "amplitude_A": a,
        "voltage_ceiling_V": capture["config"]["voltage_limit"],
        "armed_bus_V": before["g_repo_bus_mv"] / 1000,
        "outcome": capture["outcome"],
        "state": after["g_tune_state"], "reason": after["g_tune_reason"],
        "result": after["g_tune_result"], "half_moves": after["g_tune_half_moves"],
        "plateau_sample_count": len(plateau),
        "mean_A": statistics.mean(v for r, v in plateau),
        "MAE_A": statistics.mean(abs(v-r) for r, v in plateau),
        "voltage_abs_peak_V": max(map(abs, curves["g_tune_voltage"]["values"])),
        "saturated_samples": sum(v > .5 for v in curves["g_tune_saturated"]["values"]),
        "hall_changes": after["g_tune_hall_changes"] - before["g_tune_hall_changes"],
        "hall_invalid_delta": after["g_tune_hall_invalid"] - before["g_tune_hall_invalid"],
        "hall_multibit_delta": after["g_tune_hall_multibit"] - before["g_tune_hall_multibit"],
        "hall_seen_mask": hex(after["g_tune_hall_seen"]),
        "inactive_fault_irq_delta": after["g_repo_fault_irq_rejected"] - before["g_repo_fault_irq_rejected"],
        "active_fault_capture_delta": after["g_repo_fault_capture_count"] - before["g_repo_fault_capture_count"],
        "boot_lifetime_control_irq_max_us": after["g_repo_irq_max_cycles"] / 100,
        "recorder_fault": after["g_tune_recorder_fault"],
        "CPU_CFSR": after_document["registers"]["0xe000ed28"],
        "CPU_HFSR": after_document["registers"]["0xe000ed2c"],
        "outputs_disabled": (int(after_document["registers"]["0x40020414"], 16) & 1 == 0
                             and int(after_document["registers"]["0x40020814"], 16) & ((1<<6)|(1<<7)|(1<<9)) == 0
                             and int(after_document["registers"]["0x40010044"], 16) & (1<<15) == 0),
    }
    assert row["state"] == 0 and row["reason"] == 9 and row["result"] == 0
    assert row["half_moves"] == 2 and row["hall_changes"] == 48
    assert row["hall_invalid_delta"] == row["hall_multibit_delta"] == row["active_fault_capture_delta"] == 0
    assert row["outputs_disabled"]
    rows.append(row)
    selected = {"timestamp": capture["timestamp"], "summary": row,
                "signals": {k: list(map(list, zip(v["times"], v["values"]))) for k, v in curves.items()}}
    (trends / f"current-ramp-fixed-{a}a-20261111-trend.json").write_text(json.dumps(selected, indent=2) + "\n")
    ax = axes[a-1, 0]
    for signal, label, color in [("g_tune_reference", "Reference", "#111827"), ("g_tune_measured", "Measured D", "#2563eb")]:
        ax.plot(curves[signal]["times"], curves[signal]["values"], label=label, color=color, lw=1.2)
    ax.set(title=f"{a} A: mean {row['mean_A']:.3f} A; MAE {row['MAE_A']:.3f} A", xlabel="Capture time (s)", ylabel="Current (A)")
    ax.grid(alpha=.2)
    if a == 1:
        ax.legend(loc="lower right")
    ax = axes[a-1, 1]
    command = dict(zip(curves["g_tune_command_mech_rev"]["times"], curves["g_tune_command_mech_rev"]["values"]))
    samples = [(t, command[t], h) for t, h in zip(curves["g_tune_hall_state"]["times"], curves["g_tune_hall_state"]["values"]) if t in command]
    peak = max(range(len(samples)), key=lambda i: samples[i][1])
    for part, label, color in [(samples[:peak+1], "Out", "#2563eb"), (samples[peak+1:], "Return", "#ea580c")]:
        ax.plot([s[1] for s in part], [s[2] for s in part], ".", ms=2.5, color=color, label=label)
    ax.set(title=f"48 Hall edges; inactive nFAULT IRQs {row['inactive_fault_irq_delta']:,}", xlabel="Commanded mechanical rotation (rev)", ylabel="Hall UVW code", xlim=(-.02, 1.02), ylim=(.5, 6.5), yticks=range(1, 7))
    ax.grid(alpha=.2)
    if a == 1:
        ax.legend(loc="upper right")

fig.suptitle("24 V D-axis ramp: 1–5 A, Kp=1.0 / Ki=2500\nSix-second out-and-back cycles; 100 Hz trends, commanded angle assumes four pole pairs", fontsize=14)
plot = trends / "current-ramp-fixed-24v-20261111.png"
fig.savefig(plot, dpi=140)
plt.close(fig)
hex_path = archive / "repo-current-motion-24v.hex"
image_hash = (hashlib.sha256(hex_path.read_bytes()).hexdigest() if hex_path.exists()
              else json.loads((archive / "results.json").read_text())["hex_sha256"])
report = {
    "date_local": "2026-11-11", "status": "DONE_WITH_CONCERNS",
    "result": "All five bounded cycles completed; user reported normal motion and confirmed EVM OFF.",
    "image_interface": "0x1000B", "hex_sha256": image_hash,
    "archive": str(archive.relative_to(root)).replace("\\", "/"),
    "setup": {"supply_V": 24, "input_current_limit_A": 3, "kp": 1, "ki": 2500, "duration_s": 6, "alignment_s": 1, "leg_s": 2.5, "unloaded_secured_motor": True, "Halls_connected": True},
    "statistics_method": "Unweighted 100 Hz MCUViewer trend samples. Mean/MAE use common reference/measured timestamps with reference >=99.9% of requested amplitude. Voltage peak and saturation count use full captured trend. These are not raw 20 kHz extrema or time-weighted metrics. IRQ maximum is cumulative since boot.",
    "runs": rows,
    "hall_angle_limitation": "X is open-loop commanded mechanical revolutions assuming four pole pairs, not an independent shaft-angle measurement. 48 transitions per out/back and no invalid/multibit states were counted by the 20 kHz observer.",
    "remaining_concern": "Already-inactive nFAULT edges persist and rise to 7300 during the 5 A cycle. Their physical origin is unproven; electrical measurement of PB1/nFAULT, ground and bus is the next diagnostic. Repeated status reads and IRQ-entry HIGH establish the false-stop software path, not the absence of every resolved electrical transient.",
    "protection": "Active-LOW IRQ shutdown, independent SysTick LOW check, USER, ADC/current and timing guards remain enabled. No driver protection mode or threshold relaxed.",
    "software_validation": "Full ARM build; upstream23 tests/42 checks; 12V/24V/motion tuning, Recorder/mailbox/NV ASan/UBSan suites; compiled Thumb IRQ4cases, SPI reader10cases, Hall GPIO/observer audit all pass. Previous image fails inactive-edge regression.",
    "final_state": {"MCU_disarmed": True, "ENABLE_INLs_MOE_LOW": True, "EVM_power": "OFF, user confirmed", "motion_observation": "normal, user reported", "viewer": "STOP, Hall and rotation capture group; 5 A curves retained", "COM3": "untouched"},
}
(bench / "2026-11-11-current-ramp-fault-fix.json").write_text(json.dumps(report, indent=2) + "\n")
project = json.loads((root / "tools/tuning/current-loop-free-hall-24v.mcuv").read_text())
project["elf"]["path"] = "repo-current-motion-24v.elf"
(archive / "current-loop-free-hall-24v.mcuv").write_text(json.dumps(project, indent=2) + "\n")
shutil.copy2(bench / "2026-11-11-current-ramp-fault-fix.json", archive / "results.json")
shutil.copy2(plot, archive / plot.name)
with zipfile.ZipFile(trends / "current-ramp-fixed-24v-20261111.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for pattern in ["run-*.json", "run-*-readback.txt", "boot-check*", "powered-unarmed*", "analyze_results.py", "results.json"]:
        for path in sorted(archive.glob(pattern)):
            z.write(path, path.name)
manifest = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(archive.iterdir()) if p.is_file() and p.name != "manifest.json"}
(archive / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps(rows, indent=2))
